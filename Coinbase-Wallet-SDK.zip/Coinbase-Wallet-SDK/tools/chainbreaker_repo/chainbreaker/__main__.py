import chainbreaker

chainbreaker.main()
