def test_command_line():
    pass
